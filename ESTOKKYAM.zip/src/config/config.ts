// export const BASE_URL = "http://87.237.52.168:3000";
export const BASE_URL = "http://localhost:3002";
// export const BASE_URL = "https://dispossessor.com/back";
export const SOCKET_URL = "http://localhost:3003";
