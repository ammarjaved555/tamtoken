interface alertState {
  message: string;
  severity: string;
}

export type { alertState };
