// import { OrderHistoryTableType } from '../../../types/Orderhistory'
interface testState {
  rowsCount: number;
}

export type { testState };
