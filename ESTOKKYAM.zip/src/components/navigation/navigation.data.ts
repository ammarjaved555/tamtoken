export const navigations = [
  { label: "Explore", path: "/explore" },
  { label: "Offers", path: "/offers" },
  { label: "History", path: "/history" },
  { label: "Language", path: "/language" }
];
